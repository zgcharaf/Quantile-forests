# quantile_forest/quantile_forest/__init__.py

from .rf_quantile import QuantileRegressor

__all__ = ["QuantileRegressor"]
