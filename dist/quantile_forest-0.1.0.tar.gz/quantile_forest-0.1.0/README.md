# Quantile Forest

Quantile Forest is a Python library for applying quantile regression techniques to Random Forests, including RF-GAP (Random Forest with Generalized Additive Proximity) and QRF (Quantile Regression Forests).

## Installation

```bash
pip install quantile_forest
